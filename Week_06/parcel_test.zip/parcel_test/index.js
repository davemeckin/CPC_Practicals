console.log('hello world')
alert("hi:");